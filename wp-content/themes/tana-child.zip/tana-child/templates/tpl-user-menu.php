<div class="user-profile">
    <div class="follow-links">
        <span><?php esc_html_e('Follow Us:', 'tana'); ?></span>
        <?php Tana_Tpl::get_social_links(); ?>
    </div>
</div>