(function($){
	"use strict";

	var animationEnd = 'webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend';

	var isTouchDevice = function(){
	    return true == ("ontouchstart" in window || window.DocumentTouch && document instanceof DocumentTouch);
	}

	$('[data-bg-image]').each(function(){
		$(this).css({ 'background-image': 'url('+$(this).data('bg-image')+')' });
	});

	$('[data-bg-color]').each(function(){
		$(this).css({ 'background-color': $(this).data('bg-color') });
	});

	$('[data-width]').each(function(){
		$(this).css({ 'width': $(this).data('width') });
	});

	$('[data-height]').each(function(){
		$(this).css({ 'height': $(this).data('height') });
	});

	$('[data-alpha]').each(function(){
		$(this).css({ 'opacity': $(this).data('alpha') });
	});


	// build mega menu
	$('nav.main-nav').find('.menu-item.menu-item-mega').each(function(){
		var $this = $(this);
		var $list_pane = $('<div class="mega-menu-lists"></div>');
		var $content_pane = $('<div class="mega-menu-panel"></div>');
		$this.find('> ul > li').each(function(item_index){
			var _link = $(this).find('>a');
			var _row = $('<div class="row"></div>').append($(this).find('>.mega-menu-hd').html());
			if( item_index==0 ){
				_link.addClass('mm-entry');
			}
			else{
				_row.css('display', 'none');
			}
			$list_pane.append( _link );
			$content_pane.append( _row );
		});

		var _mm = $('<ul><li></li></ul>')
		_mm.find('li').append($list_pane).append($content_pane);
		$this.find('> ul').replaceWith(_mm);

		$this.find('.mega-menu-lists > a').on('mouseenter', function(){
			$this.find('.mega-menu-lists > a.mm-entry').removeClass('mm-entry');
			$(this).addClass('mm-entry');
			var _cur_index = $this.find('.mega-menu-lists > a').index($(this));
			$this.find('.mega-menu-panel > .row').hide();
			$this.find('.mega-menu-panel > .row').eq(_cur_index).show();
		});
	});



	// build welcome menu
	if( $('.welcome-nav-hidden').length ){
		$('.welcome-nav-hidden').find('> ul > li').each(function(){
			var _a = $(this).find('> a').clone();
			_a.addClass( $(this).attr('class') );
			$('.welcome-navigation-menu').append(_a);
		});
		if( $('.welcome-nav-hidden').find('> ul').hasClass('one-page-menu') ){
			$('.welcome-navigation-menu').addClass('one-page-menu');
		}
	}



	// configure tabs
	$('.vc_tta.vc_tta-tabs.vc_tta-style-classic').each(function(){
		var _tab = $(this);
		var $navs = $('<div class="tab-title clearfix"></div>');
		var $panels = $('<div class="tab-panel"></div>');
		var $tab = $('<div class="simple-tab-space"></div>');

		var _panels = _tab.find('.vc_tta-panels-container > .vc_tta-panels');
		_panels.find('> .vc_tta-panel').each(function(){
			var _nav = $('<a href="javascript:;"></a>');
			var _pane = $('<div class="tab-content"></div>');
			if( $(this).hasClass('vc_active') ){
				_pane.addClass('active');
				_nav.addClass('active');
			}
			_nav.html( $(this).find('.vc_tta-panel-title > a').html() );
			$navs.append( _nav );

			_pane.html( $(this).find('.vc_tta-panel-body').html() );
			$panels.append(_pane);
		});

		$tab.append($navs);
		$tab.append($panels);

		if( _tab.parent().data('tab-style')=='ms-style' ){
			$tab.addClass('ms-style');
		}
		if( _tab.parent().data('text-style')=='text-light' ){
			$tab.addClass('text-light');
		}

		_tab.parent().replaceWith($tab);
	});


	// configure parallax row
	$('div[data-parallax-row="fast-and-slow"]').each(function(){
		var _row = $(this);
		_row.addClass('parallax-columns-container');
		_row.find('> div').each(function(){
			var _col = $(this);
			if( _col.data('parallax')=='parallax-content' ){
				_col.find('> .vc_column-inner > .wpb_wrapper').addClass('parallax-content');
			}
			else{
				_col.find('> .vc_column-inner').addClass('parallax-col-wrap');
				_col.find('> .vc_column-inner > .wpb_wrapper').addClass('parallax-column');
			}
		});
	});
	$('div[data-parallax-row="parallax"]').each(function(){
		var _row = $(this);
		_row.addClass('sticky-parent');
		_row.find('> div').each(function(){
			var _col = $(this);
			_col.addClass('sticky-column');
			_col.find('> .vc_column-inner').addClass('theiaStickySidebar');
		});
	});



	$(document).ready(function(){

		// check supports mix-blend-mode
		if ('CSS' in window && 'supports' in window.CSS) {
			var supportsMixBlendMode = window.CSS.supports('mix-blend-mode', 'multiply');
			if( !supportsMixBlendMode ){
				$('.fs-slide.fn-slide').addClass('no-blend-mode');
			}
		}

		/* Sub menu */
		$('nav.main-nav li:has(> ul)').addClass('menu-item-has-children');

		/* Mega Menu */
		$('nav.main-nav').find('.menu-item-mega').each(function(){
			var _mega = $(this);
			var _left = $('nav.main-nav').offset().left;
			_left = _left - _mega.offset().left;
			_mega.find('> ul').css({
				'left': _left+'px',
				'width': $('nav.main-nav').width()+'px'
			});
		});
		// responsive for mega menu
		$(window).resize(function(){
			$('nav.main-nav').find('.menu-item-mega').each(function(){
				var _mega = $(this);
				var _left = $('nav.main-nav').offset().left;
				_left = _left - _mega.offset().left;
				_mega.find('> ul').css({
					'left': _left+'px',
					'width': $('nav.main-nav').width()+'px'
				});
			});
		});



		/* Push Menu */
		$('.burger-menu').on('click', function(){
			if( $(this).hasClass('pm-right') ){
				if( !$('.push-menu').hasClass('pm-right') ){
					$('.push-menu').addClass('pm-right');
					setTimeout(function(){
						$('.push-menu').addClass('show-pm');
						$('html,body').addClass('opened-push-sidebar');
					}, 200);
				}
				else{
					$('.push-menu').addClass('show-pm');
					$('html,body').addClass('opened-push-sidebar');
				}
			}
			else{
				if( $('.push-menu').hasClass('pm-right') ){
					$('.push-menu').removeClass('pm-right');
					setTimeout(function(){
						$('.push-menu').addClass('show-pm');
						$('html,body').addClass('opened-push-sidebar');
					}, 200);
				}
				else{
					$('.push-menu').addClass('show-pm');
					$('html,body').addClass('opened-push-sidebar');
				}
			}
		});
		// click close pm
		$('.push-menu .close-menu').on('click', function(){
			$('.push-menu').removeClass('show-pm');
			$('html,body').removeClass('opened-push-sidebar');
		});
		// click overlay white space
		$('.push-menu .pm-overlay').on('mouseup', function(e){
			var container = $('.push-menu .pm-container');
			if (!container.is(e.target) && container.has(e.target).length === 0){
		        $('.push-menu .close-menu').trigger('click');
		    }
		});
		// press ESC button
		$(document).keyup(function(e) {
     		if (e.keyCode == 27) {
	        	if( $('.push-menu').hasClass('show-pm') ){
	        		$('.push-menu .close-menu').trigger('click');
	        	}
	    	}
		});


		// fixed footer
		if( $('body').hasClass('fixed-footer') ){
			$('body > .wrapper > .content-area').css({ 'margin-bottom': $('#footer').outerHeight() + 'px' });
			$(window).resize(function(){
				$('body > .wrapper > .content-area').css({ 'margin-bottom': $('#footer').outerHeight() + 'px' });
			});
		}


		/* Scroll to top anchor */
		$('.scroll-to-top').on('click', function(){
			$('html,body').animate({scrollTop: 0}, 'slow');
			return false;
		});
		$('.scroll-to').on('click', function(e){
			$('html,body').animate({scrollTop: $($(this).attr('href')).offset().top}, 'slow');
			return false;
		});



		// <<< one page menu
		$('.one-page-menu a').on('click', function(){
			var $this = $(this);
			var href = $this.attr('href') + '';
			href = href.replace('#', '');

			var $row_c = $('div[data-onepage-slug="'+href+'"]');
			if( $row_c.length ){
				var otop = $row_c.offset().top;
				if(otop<0){ otop = 0; }
				$("html, body").animate({ scrollTop: otop }, "slow");
			}
			return false;
		});
		// one page menu >>>


		/* News slider block */
		$('.image').each(function(){
			if ( typeof $(this).data('src') !== 'undefined' && $(this).data('src') != '' ) {
				$(this).css('background-image', 'url('+$(this).data('src')+')');
			}
		});


		/* Modal video player */
		$('body:not(.disable-video-lightbox) .video-player:not(.playpermalink),.player-popup').each(function(){
			var _video = $(this);
			_video.magnificPopup({
				type: 'iframe',
				disableOn: 700,
				preloader: false,
				fixedContentPos: false
			});
			_video.on('click', function(){
				return false;
			});
		});
		$('.video-frame').on('click', function(event){
			var _this = $(this);

			if( _this.find('body:not(.disable-video-lightbox) .video-player:not(.playpermalink)').length ){
				event.preventDefault();
				$.magnificPopup.open({
					items: {
						src: _this.find('.video-player').attr('href')
					},
					type: 'iframe'
				});
				return false;
			}
			else if( _this.find('.video-player').length ){
				event.preventDefault();
				window.location = _this.find('.video-player').attr('href');
			}

		});



		var msLayerAnimater = function(_active){
			_active.find('.animate-element').each(function(ai){
    			var _el = $(this),
    				_anim = _el.data('anim');

    			_el.css({
    				'-webkit-animation-duration': "0.5s",
    				   '-moz-animation-duration': "0.5s",
    					'-ms-animation-duration': "0.5s",
    					 '-o-animation-duration': "0.5s",
    						'animation-duration': "0.5s"
    			});

    			_el.css({
    				'-webkit-animation-delay': (ai*0.2)+"s",
    				   '-moz-animation-delay': (ai*0.2)+"s",
    					'-ms-animation-delay': (ai*0.2)+"s",
    					 '-o-animation-delay': (ai*0.2)+"s",
    						'animation-delay': (ai*0.2)+"s"
    			});
    			_el.addClass('animated ' + _anim);

    			_el.one(animationEnd, function() {
		            $(this).removeClass('animated ' + _anim);
		        });
    		});
		};

		/* News slider */
		$('.news-slider').each(function(){
			var _news_slider = $(this);
			var _id = _news_slider.find('.master-slider').attr('id');
			var slider = new MasterSlider();
			var sliderHeight = 640;
			var autoplay = _news_slider.find('.master-slider').data('autoplay');

			slider.control('circletimer' , {color:"#FFFFFF" , stroke:9});

			if(_news_slider.hasClass('news-slider-hover')) {

				slider.control('thumblist' , { autohide:false ,dir:'v',type:'tabs', align:'right', margin:0, space:25, width:0, height:105, hideUnder:640 });
				slider.control('scrollbar' , '');
				sliderHeight = 600;

			} else {
				slider.control('arrows');
				slider.control('thumblist' , { autohide:false ,dir:'v',type:'tabs', align:'right', margin:10, space:25, width:280, height:175, hideUnder:640 });
				slider.control('scrollbar' , {dir:"v"});
			}

			slider.setup(_id , {
				width:1170,
				height:sliderHeight,
				space:0,
				speed: 100,
				view:'fade',
				autoplay: autoplay
			});

			setTimeout(function(){
				slider.api.addEventListener(MSSliderEvent.CHANGE_END , function(){
			    	msLayerAnimater(_news_slider.find('.ms-slide.ms-sl-selected'));
				});
			}, 400);

		});


		/* Entertainment slider */
		$('.entertainment-slider').each(function(){
			var _news_slider = $(this);
			var _id = _news_slider.find('.master-slider').attr('id');
			var slider = new MasterSlider();
			var sliderHeight = 840;
			var autoplay = _news_slider.find('.master-slider').data('autoplay');

			slider.control('thumblist' , {autohide:false ,dir:'v',type:'tabs', align:'right', margin:0, space:10, width:0, height: 150, hideUnder:640});
			slider.control('scrollbar' , '');

			slider.setup(_id , {
				width:1170,
				height:sliderHeight,
				space:0,
				view:'fade',
				layout: 'fillwidth',
				autoplay: autoplay
			});

			setTimeout(function(){
				slider.api.addEventListener(MSSliderEvent.CHANGE_END , function(){
			    	msLayerAnimater(_news_slider.find('.ms-slide.ms-sl-selected'));
				});
			}, 400);

		});



		/* Gallery slider */
		$('.gallery-slider').each(function(){
			var _news_slider = $(this);
			var _id = _news_slider.find('.master-slider').attr('id');
			var slider = new MasterSlider();
			var sliderHeight = 640;
			var _speed = parseInt(_news_slider.data('speed'), 10);
				_speed = _speed > 0 ? _speed : 0;

			var _thumb_width = 90;
			var _thumb_height = 60;
			var _thumb_space = 10;
			var autoplay = _news_slider.find('.master-slider').data('autoplay');

			if( _news_slider.hasClass('movie-slider') ) {
				_thumb_width = 270;
				_thumb_height = 160;
				_thumb_space = 30;
			}

		    slider.control('thumblist' , {autohide:false, dir:'h', type:'tabs', width:_thumb_width, height:_thumb_height, align:'bottom', space:_thumb_space, margin:0, hideUnder:400});
		 	slider.control('arrows', {autohide: false});
		 	slider.control('scrollbar' , {dir:'h',color:'#444',align:'bottom',autohide:false,margin:20,width:2});

		 	var _options = {
		        width: 1170,
		        height: sliderHeight,
		        space:0,
		        preload:'all',
		        view:'basic',
		        autoplay: autoplay
		    };

		    if( _speed > 0 ){
		    	_options = $.extend(_options, {speed:_speed});
		    }

		    slider.setup( _id, _options);

		    setTimeout(function(){
				slider.api.addEventListener(MSSliderEvent.CHANGE_END , function(){
			    	msLayerAnimater(_news_slider.find('.ms-slide.ms-sl-selected'));
				});
			}, 400);

		});



		// Personal Blog Main Slider
		setTimeout(function(){
			$('.fs-slide').each(function(){
				var _slider = $(this);
				var _autoplay = $(this).find('.swiper-container').data('autoplay');

				_slider.find('.swiper-container').swiper({
					slidesPerView: 1,
					spaceBetween: 0,
					speed: 800,
					loop: true,
					autoHeight: true,
					autoplay: _autoplay,
					nextButton: _slider.find('.fs-arrow-next'),
				    prevButton: _slider.find('.fs-arrow-prev'),
				    pagination: _slider.find('.fs-pagination'),
	        		paginationClickable: true,
	        		onSlideChangeStart: function(swiper){
	        			if( _slider.hasClass('fn-slide') ){
	        				var _active = _slider.find('.swiper-slide').eq(swiper.activeIndex);
	        				_slider.find('.fn-meta-views').text(_active.find('.fs-item').data('views'));
	        				_slider.find('.fn-meta-comments').text(_active.find('.fs-item').data('comments'));
	        			}
	        		},
				    onSlideNextStart: function(swiper){
				    	var _active = _slider.find('.swiper-slide').eq(swiper.activeIndex);

			    		_active.find('.fs-animate-text').each(function(ai){
			    			var _el = $(this);
			    			_el.css({
			    				'-webkit-animation-delay': (ai*0.2)+"s",
			    				   '-moz-animation-delay': (ai*0.2)+"s",
			    					'-ms-animation-delay': (ai*0.2)+"s",
			    					 '-o-animation-delay': (ai*0.2)+"s",
			    						'animation-delay': (ai*0.2)+"s"
			    			});
			    			_el.addClass('animated fadeInRight');

			    			_el.one(animationEnd, function() {
					            $(this).removeClass('animated fadeInRight');
					        });
			    		});
				    },
				    onSlidePrevStart: function(swiper){
				    	var _active = _slider.find('.swiper-slide').eq(swiper.activeIndex);
			    		_active.find('.fs-animate-text').each(function(ai){
			    			var _el = $(this);
			    			_el.css({
			    				'-webkit-animation-delay': (ai*0.2)+"s",
			    				   '-moz-animation-delay': (ai*0.2)+"s",
			    					'-ms-animation-delay': (ai*0.2)+"s",
			    					 '-o-animation-delay': (ai*0.2)+"s",
			    						'animation-delay': (ai*0.2)+"s"
			    			});
			    			_el.addClass('animated fadeInLeft');

			    			_el.one(animationEnd, function() {
					            $(this).removeClass('animated fadeInLeft');
					        });
			    		});
				    }
				});
			});


			/* fn fullwidth slide */
			$('.fn-fullslide').each(function(){
				var _slider = $(this);

				_slider.find('.swiper-container').swiper({
					slidesPerView: 'auto',
					centeredSlides: true,
					spaceBetween: 80,
					speed: 800,
					loop: true,
					nextButton: _slider.find('.fn-arrow-next'),
				    prevButton: _slider.find('.fn-arrow-prev'),
				    pagination: _slider.find('.fn-pagination'),
	        		paginationClickable: true
				});
			});



			/* welcome slider */
			$('.wslider').each(function(){
				var _slider = $(this);

				_slider.find('.swiper-container').swiper({
					slidesPerView: 'auto',
					centeredSlides: true,
					spaceBetween: 80,
					speed: 800,
					loop: true,
					nextButton: _slider.find('.ws-arrow-next'),
				    prevButton: _slider.find('.ws-arrow-prev'),
				    pagination: _slider.find('.ws-pagination'),
	        		paginationClickable: true
				});
			});


			/* Swiper carousel */
			$('.article-carousel').each(function(){
				var $this = $(this);
				$this.find('.swiper-container').css('width', '100%');
				$this.find('.swiper-container').swiper({
					slidesPerView: 1,
					spaceBetween: 30,
					nextButton: $this.find('.swiper-button-next'),
				    prevButton: $this.find('.swiper-button-prev'),
				});
			});


			// Gallery slideshow: Post format
			$('.gallery-slideshow').each(function(){
				var _gallery = $(this);

				_gallery.find('.gallery-container').swiper({
				    nextButton: _gallery.find('.swiper-button-next'),
				    prevButton: _gallery.find('.swiper-button-prev')
				});
			});


			$('.m-dimension-carousel').each(function(){
				var $this = $(this),
					_col = $this.data('col'),
					_row = $this.data('row'),
					_perView = _col * _row;

				$this.find('.swiper-container').css('width', '100%');
				$this.find('.swiper-container').swiper({
					slidesPerView: _col,
					slidesPerGroup: _col,
			        slidesPerColumn: _row,
					spaceBetween: 30,
					nextButton: $this.find('.swiper-button-next'),
				    prevButton: $this.find('.swiper-button-prev'),
				    breakpoints: {
			            768: {
			                slidesPerView: 3,
			                slidesPerGroup: 3
			            },
			            640: {
			                slidesPerView: 2,
			                slidesPerGroup: 2
			            },
			            480: {
			                slidesPerView: 1,
			                slidesPerGroup: 1
			            }
			        }
				});
			});



			// Personal Blog footer instagram
			$('.footer-instagram .swiper-container').swiper({
				slidesPerView: 6,
				breakpoints: {
		            1024: {
		                slidesPerView: 6
		            },
		            768: {
		                slidesPerView: 3
		            },
		            640: {
		                slidesPerView: 3
		            },
		            320: {
		                slidesPerView: 2
		            }
		        }
			});


			// carousel travel
			$('.carousel-travel').each(function(){
				var $this = $(this);
				var _col = $this.data('columns');
				var _space = $this.data('space');
				var _play = parseInt($this.data('autoplay'), 10);
				$this.find('.swiper-container').swiper({
					slidesPerView: _col,
					spaceBetween: _space,
					autoplay: _play,
					nextButton: $this.find('.swiper-button-next'),
				    prevButton: $this.find('.swiper-button-prev'),
				    breakpoints: {
				    	996: {
				    		slidesPerView: 3
				    	},
				    	767: {
				    		slidesPerView: 2
				    	},
				    	500: {
				    		slidesPerView: 1
				    	}
				    }
				});

				$this.addClass('loaded');
			});




			$('.tana-slider-with-thumb').each(function(){
				var $this = $(this),
					_initialSlide = 0,
					_autoplay = parseInt($this.data('autoplay'), 10);

				if( _autoplay>0 ){ _autoplay = _autoplay*1000; }
				if( $this.find('.ts-main-panel').find('.swiper-slide').length>2 ){ _initialSlide = 2; }

				var galleryTop = $this.find('.ts-main-panel').swiper({
					slidesPerView: 1,
			        nextButton: $this.find('.swiper-button-next'),
			        prevButton: $this.find('.swiper-button-prev'),
			        spaceBetween: 0,
			        autoHeight: true,
			        initialSlide: _initialSlide,
			        autoplay: _autoplay,
			        onSlideNextStart: function(swiper){
				    	var _active = $this.find('.ts-main-panel').find('.swiper-slide').eq(swiper.activeIndex);

			    		_active.find('.animate-element').each(function(ai){
			    			var _el = $(this);
			    			_el.css({
			    				'-webkit-animation-duration': "0.5s",
			    				   '-moz-animation-duration': "0.5s",
			    					'-ms-animation-duration': "0.5s",
			    					 '-o-animation-duration': "0.5s",
			    						'animation-duration': "0.5s"
			    			});
			    			_el.css({
			    				'-webkit-animation-delay': (ai*0.2)+"s",
			    				   '-moz-animation-delay': (ai*0.2)+"s",
			    					'-ms-animation-delay': (ai*0.2)+"s",
			    					 '-o-animation-delay': (ai*0.2)+"s",
			    						'animation-delay': (ai*0.2)+"s"
			    			});
			    			_el.addClass('animated fadeInRight');

			    			_el.one(animationEnd, function() {
					            $(this).removeClass('animated fadeInRight');
					        });
			    		});
				    },
				    onSlidePrevStart: function(swiper){
				    	var _active = $this.find('.ts-main-panel').find('.swiper-slide').eq(swiper.activeIndex);
			    		_active.find('.animate-element').each(function(ai){
			    			var _el = $(this);
			    			_el.css({
			    				'-webkit-animation-duration': "0.5s",
			    				   '-moz-animation-duration': "0.5s",
			    					'-ms-animation-duration': "0.5s",
			    					 '-o-animation-duration': "0.5s",
			    						'animation-duration': "0.5s"
			    			});
			    			_el.css({
			    				'-webkit-animation-delay': (ai*0.2)+"s",
			    				   '-moz-animation-delay': (ai*0.2)+"s",
			    					'-ms-animation-delay': (ai*0.2)+"s",
			    					 '-o-animation-delay': (ai*0.2)+"s",
			    						'animation-delay': (ai*0.2)+"s"
			    			});
			    			_el.addClass('animated fadeInLeft');

			    			_el.one(animationEnd, function() {
					            $(this).removeClass('animated fadeInLeft');
					        });
			    		});
				    }
			    });

			    var galleryThumbs = $this.find('.ts-thumbs-panel').swiper({
					centeredSlides: true,
					slidesPerView: 'auto',
					spaceBetween: 30,
					touchRatio: 0.2,
					slideToClickedSlide: true,
					initialSlide: _initialSlide
			    });

			    galleryTop.params.control = galleryThumbs;
			    galleryThumbs.params.control = galleryTop;

			});


		}, 400);



		$('.tt-el-ticker').each(function(){
			var _ticker = $(this);
			var _strings = [];
			if( _ticker.find('.entry-ticker').find('span').length==0 ){
				_ticker.find('.entry-ticker').append('<span>Hello, Tana Wordpress Theme - Customizer/Ticker Options</span>');
			}
			_ticker.find('.entry-ticker').find('span').each(function(){
				_strings.push($(this).html());
			});
			_ticker.find('.entry-ticker').html('');

			var option_tick = {
				strings: _strings,
				startDelay: 0,
				typeSpeed: -500,
				backSpeed: -800,
				backDelay: 5000,
				loop: true,
				onStringTyped: function(curStrPos){ },
				preStringTyped: function(curStrPos){
					_ticker.attr('data-current', curStrPos);
				}
			};

			_ticker.find('.entry-ticker').typed(option_tick);

			_ticker.find('.ticker-arrow-prev').on('click', function(){
				_ticker.attr('data-current', 0);

				var _cur = parseInt(_ticker.attr('data-current'), 10);
				var _cur_str = [];
				_cur = (_cur==0) ? (_strings.length-1) : _cur-1;

				for(var i=_cur; i<_strings.length; i++){
					_cur_str.push(_strings[i]);
				}

				for(var i=0; i<_cur; i++){
					_cur_str.push(_strings[i]);
				}

				option_tick = $.extend(option_tick, {strings: _cur_str});
				_ticker.find('.entry-ticker').html(_cur_str[0]);
				_ticker.find('.entry-ticker').typed(option_tick);
			});

			_ticker.find('.ticker-arrow-next').on('click', function(){
				_ticker.attr('data-current', 0);

				var _cur = parseInt(_ticker.attr('data-current'), 10);
				var _cur_str = [];
				_cur = (_cur==_strings.length-1) ? 0 : _cur+1;

				for(var i=_cur; i<_strings.length; i++){
					_cur_str.push(_strings[i]);
				}

				for(var i=0; i<_cur; i++){
					_cur_str.push(_strings[i]);
				}

				option_tick = $.extend(option_tick, {strings: _cur_str});
				_ticker.find('.entry-ticker').html(_cur_str[0]);
				_ticker.find('.entry-ticker').typed(option_tick);
			});

		});


		// Header sticky
		if( $('#header').hasClass('header-sticky') ){
			var headerHeight = $('#header.sticky').height();
			var lastScroll = $(window).scrollTop;
			$(window).scroll(function(){
		        var scroll = $(window).scrollTop();

		        if( scroll>400 ){
		        	$('#header').addClass('sticky');

		        	if( $('#header').hasClass('sticky-permanent') ){
		        		$("#header.sticky").addClass('unpinned');
		        	}
		        	else{
		        		if (scroll > lastScroll && headerHeight < lastScroll) {
				            $("#header.sticky").removeClass('unpinned');
				        }
				        else if (scroll < lastScroll && scroll < lastScroll - 20 || scroll < headerHeight) {
				            $("#header.sticky").addClass('unpinned');
				        }
		        	}
		        }
		        else{
		        	$("#header.sticky").removeClass('unpinned');
		        	setTimeout(function(){
		        		$('#header').removeClass('sticky');
		        	}, 300);
		        }
		        lastScroll = scroll;
		    });
		}


	    // Profile dropdown
	    $('#header .user-profile .entry-name').on('click', function(){
	    	$(this).find('.entry-dropdown').toggleClass('open');
	    });
	    $(document).on('mouseup', function(e){
	    	if( $('#header .user-profile .entry-name').find('.entry-dropdown').hasClass('open') ){
	    		var container = $('#header .user-profile .entry-name');
				if (!container.is(e.target) && container.has(e.target).length === 0){
			        $('#header .user-profile .entry-name').find('.entry-dropdown').toggleClass('open')
			    }
	    	}
		});


		// Search form handler
		$('#search_handler').on('click', function(){
			$('#header').toggleClass('show-search');
			setTimeout(function(){
				$('#header .search-panel input').eq(0).focus();
			}, 100);
		});

		$('#header .search-panel a.close-search').on('click', function(){
			$('#header').removeClass('show-search');
		});

		$('.search-handler.search-fashion').on('click', function(){
			$(this).parent().toggleClass('show-form');
			if( $(this).parent().hasClass('show-form') ){
				$(this).parent().find('form input[type="text"]').eq(0).focus();
			}
		});


		// Simple Tab
		$('.simple-tab-space').each(function(){
			var _tab = $(this);
			_tab.find('.tab-title a').on('click', function(event){
				event.preventDefault();
				_tab.find( ".tab-title a" ).removeClass('active');
				$(this).addClass('active');
				_tab.find( ".tab-panel .tab-content" ).removeClass('active');
				_tab.find( ".tab-panel .tab-content" ).eq( _tab.find(".tab-title a").index($(this)) ).addClass('active');
			});
		});


		// Circle chart
		$('.circle-chart').each(function(ci){
			var _circle = $(this),
				_id = 'circle-chart' + ci,
				_width = _circle.data('circle-width'),
				_percent = _circle.data('percent'),
				_text = _circle.data('text');

			_percent = (_percent + '').replace('%', '');
			_width = parseInt(_width, 10);

			_circle.attr('id', _id);
			var _cc = Circles.create({
				id:         _id,
				value:		_percent,
				text: 		_text,
				radius:     100,
				width:      _width,
				colors:     ['rgba(255,255,255, .05)', '#f84432']
			});

		});



		// Twitter share
		$('.twitter-shareable').on('click', function(){
			var _share = $(this);
			var _addr = window.location.href;
			window.open("http://twitter.com/share?url="+_addr+"&text="+_share.text(),"twitterwindow","height=450, width=550, top="+($(window).height()/2-225)+", left="+($(window).width()/2-275));
		});



		// Personal blog carousel
		$('.fs-blog-carousel').each(function(){
			var $fs = $(this),
				_col = $fs.data('col'),
				_row = $fs.data('row'),
				_responsive = $fs.data('responsive') + '',
				_pager = 0,
				_perView = _col * _row,
				_arr_responsive = [3,2,1],
				_autoplay = $fs.data('autoplay');

			var _space = 30;
			if( $fs.hasClass('testimonial-slider') == true ){
				_space = 0;
			}

			if( _responsive!=='undefined' ){
				var _exp = _responsive.split(',');
				if( _exp.length>2 ){
					_arr_responsive[0] = parseInt(_exp[0], 10);
					_arr_responsive[1] = parseInt(_exp[1], 10);
					_arr_responsive[2] = parseInt(_exp[2], 10);
				}
				else if( _exp.length==2 ){
					_arr_responsive[0] = parseInt(_exp[0], 10);
					_arr_responsive[1] = parseInt(_exp[1], 10);
					_arr_responsive[2] = parseInt(_exp[1], 10);
				}
				else if( _exp.length==1 ){
					_arr_responsive[0] = parseInt(_exp[0], 10);
					_arr_responsive[1] = parseInt(_exp[0], 10);
					_arr_responsive[2] = parseInt(_exp[0], 10);
				}
			}

			_pager = ($fs.find('.swiper-slide').length % _perView) > 0 ? parseInt($fs.find('.swiper-slide').length / _perView, 10)+1 : parseInt($fs.find('.swiper-slide').length / _perView, 10);

			$fs.find('.fs-current-total').html(_pager);
			//fs-current-index

			$fs.find('.swiper-container').swiper({
				pagination: '.swiper-pagination',
		        slidesPerView: _col,
		        slidesPerGroup:_col,
		        slidesPerColumn: _row,
		        paginationClickable: true,
		        spaceBetween: _space,
		        autoplay: _autoplay,
			    prevButton: $fs.find('.swiper-prev'),
			    nextButton: $fs.find('.swiper-next'),
			    onSlideChangeEnd: function(swiper){
			    	var _current = (swiper.activeIndex % _col)>0 ? parseInt(swiper.activeIndex / _col) + 2 : parseInt(swiper.activeIndex / _col) + 1;
			    	$fs.find('.fs-current-index').html(_current);
			    },
			    breakpoints: {
		            768: {
	                	slidesPerView: _arr_responsive[0]
		            },
		            640: {
	                	slidesPerView: _arr_responsive[1]
		            },
		            320: {
		                slidesPerView: _arr_responsive[2]
		            }
		        }
			});
		});



		// Scroll indicator
		$(window).scroll(function(){
			var _document_height = $(document).height(),
				_window_height = $(window).height(),
				_scroll_top = $(window).scrollTop(),
				_w = 0;

			_w = _scroll_top*100/(_document_height-_window_height);

			$('.scroll-window-indicator').find('> div').width(_w+'%');
		});


		// animated blocks
		$('.animated-blocks').each(function(){
			var _block = $(this);

			_block.waypoint({
				handler: function(direction){
					if( !_block.hasClass('ab-animated') ){
						_block.find('.ab-item').each(function(bi){
							var _el = $(this);
			    			_el.css({
			    				'-webkit-animation-delay': (bi*0.1)+"s",
			    				   '-moz-animation-delay': (bi*0.1)+"s",
			    					'-ms-animation-delay': (bi*0.1)+"s",
			    					 '-o-animation-delay': (bi*0.1)+"s",
			    						'animation-delay': (bi*0.1)+"s"
			    			});
			    			_el.addClass('animated fadeInUp ab-visible');

			    			_el.one(animationEnd, function() {
					            $(this).removeClass('animated fadeInUp');
					        });
						});

						_block.addClass('ab-animated');
					}
				},
				continuous: false,
		  		offset: '95%'
			});
		});



		$('a.ms-love').on('click', function(){
			$(this).toggleClass('active');
		});


		// update weather
		if( $('.weather-update-required').length ){
			$.post(theme_options.ajax_url, {action:'tana_get_weather_info', renew:true}, function(data){
				var _response = parseInt(data, 10);
				$('.weather-update-required').find('span').eq(0).html(_response);
			});
		}


		// woocommerce
		if( $('.woocommerce.single-product .content-area .product .images .thumbnails').length ){
			$('.woocommerce.single-product .content-area .product .images').append('<a href="javascript:;" class="woo-single-arrow-up"><i class="fa fa-angle-up"></i></a>');
			$('.woocommerce.single-product .content-area .product .images').append('<a href="javascript:;" class="woo-single-arrow-down"><i class="fa fa-angle-down"></i></a>');

			$('.woo-single-arrow-up').on('click', function(){
				var _scroll_top = $('.woocommerce.single-product .content-area .product .images .thumbnails').scrollTop();
				_scroll_top -= 100;
				$('.woocommerce.single-product .content-area .product .images .thumbnails').stop().animate({
					scrollTop: _scroll_top + 'px'
				});
			});

			$('.woo-single-arrow-down').on('click', function(){
				var _scroll_top = $('.woocommerce.single-product .content-area .product .images .thumbnails').scrollTop();
				_scroll_top += 100;
				$('.woocommerce.single-product .content-area .product .images .thumbnails').stop().animate({
					scrollTop: _scroll_top + 'px'
				});
			});
		}
		else{
			if( $('.woocommerce.single-product .content-area .product .images').length ){
				$('.woocommerce.single-product .content-area .product .images').addClass('no-thumbnails');
			}
			if( $('.woocommerce.single-product .content-area div.product .onsale').length ){
				$('.woocommerce.single-product .content-area div.product .onsale').addClass('no-thumbnails');
			}

		}

		$('.music-single .action-play-list').on('click', function(){
			if( $('.music-single .mejs-play button').length ){
				$('.music-single .mejs-play button').eq(0).trigger('click');
			}
		});

	});



	if( $('#msplayer').length ){
		var svg_pp = new SVGMorpheus('#ms_play_pause');
		var svg_vol = new SVGMorpheus('#ec_volume');

		$('#msplayer').mediaelementplayer({
			features: ['current','progress','duration','tracks'],
			success: function(media, node, player) {
				var events = ['loadstart', 'play','pause', 'ended'];
				var playlist = {playing:0, list:[]};

				$('#music_player .pl-list').find('.tr-item').each(function(){
					var _row = $(this);
					var _rid = _row.data('id');
					var _audio = _row.find('.pl-audio-item').data('url');
					var _thumb = _row.find('.pl-audio-item').data('thumb');
					var _title = _row.find('.pl-audio-item').find('.pl-item-title').text();
					var _artist = _row.find('.pl-audio-item').find('.pl-item-artist').text();

					playlist.list.push({ id:_rid, audio:_audio, thumb:_thumb, title:_title, artist:_artist});
				});


				// load song
				var load_song = function(load_index){
					if( playlist.list.length>0 && playlist.list.length>load_index && load_index>-1 ){
						var _current_media = playlist.list[load_index];
						playlist.playing = load_index;
						media.setSrc(_current_media.audio);
						media.load();

						$('#music_player .ms-nowplaying').find('.np-thumb').css('background-image', 'url('+_current_media.thumb+')');
						$('#music_player .ms-nowplaying').find('.np-title').text(_current_media.title);
						$('#music_player .ms-nowplaying').find('.np-artist').text(_current_media.artist);
						$('#music_player .pl-list').find('.tr-item .td-num .number.playing').removeClass('playing');
						$('#music_player .pl-list').find('.tr-item').eq(load_index).find('.td-num .number').addClass('playing');
					}
				}

				// play song
				var play_song = function(){
					media.play();
				}

				// play previous previous
				var play_prev = function(){
					if( playlist.playing == 0 && playlist.list.length>0 ){
						playlist.playing = playlist.list.length-1;
					}
					else{
						playlist.playing = playlist.playing - 1;
					}
					load_song(playlist.playing);
					play_song();
				}

				// play next song
				var play_next = function(){
					if( playlist.list.length>0 && playlist.playing == playlist.list.length-1 ){
						playlist.playing = 0;
					}
					else{
						playlist.playing = playlist.playing + 1;
					}

					if( $('#music_player .ms-control-shuffle').hasClass('active') ){
						playlist.playing = Math.floor(Math.random() * playlist.list.length-1);
					}

					load_song(playlist.playing);
					play_song();
				}

				// set first audio file
				if( playlist.list.length ){
					load_song(0);
				}

				// player events
				for (var i=0, il=events.length; i<il; i++) {
					var eventName = events[i];
					media.addEventListener(events[i], function(e) {
						if( e.type=='play' ){
							$('#music_player .ms-play').addClass('ms-pause');
							svg_pp.to('ms_pause', {duration:400, rotation:'none'});
						}
						else if( e.type=='pause' ){
							$('#music_player .ms-play').removeClass('ms-pause');
							svg_pp.to('ms_play', {duration:400, rotation:'none'});
						}
						else if( e.type=='loadstart' ){

						}
						else if( e.type=='ended' ){
							var _current_number = playlist.playing;

							if( playlist.playing==playlist.list.length-1 ){
								if( $('#music_player .ms-control-repeat').hasClass('active') ){
									_current_number = 0;
								}
								else{
									_current_number = -1;
								}
							}
							else{
								if( $('#music_player .ms-control-shuffle').hasClass('active') ){
									_current_number = Math.floor(Math.random() * playlist.list.length-1);
								}
								else{
									_current_number += 1;
								}

							}

							console.log('ended', _current_number);

							if( _current_number>-1 ){
								load_song(_current_number);
								play_song();
							}
						}
					});
				}

				// play action
				$('#music_player .ms-play').on('click', function(){
					if (media.paused){
						media.play();
					}
					else{
						media.pause();
					}
				});

				// previous action
				$('#music_player .ms-prev').on('click', function(){
					play_prev();
				});

				// next action
				$('#music_player .ms-next').on('click', function(){
					play_next();
				});

				// Volume
				$('#music_player .ec-vol-el').slider({
					orientation: "vertical",
					range: "min",
					min: 0,
					max: 100,
					value: 80,
					slide: function( event, ui ) {
						media.setVolume(ui.value/100);
					}
				});

				$('#music_player .ms-controls .ec-volume a').on('click', function(){
					$(this).toggleClass('ec-vol-mute');
					if( $(this).hasClass('ec-vol-mute') ){
						media.setVolume(0);
						svg_vol.to('vol_mute', {duration:400, rotation:'none'});
						$('#music_player .ec-vol-el').slider('value', 0);
					}
					else{
						media.setVolume(0.8);
						svg_vol.to('vol_max', {duration:400, rotation:'none'});
						$('#music_player .ec-vol-el').slider('value', 80);
					}
				});

				// shuffle
				$('#music_player .ms-control-shuffle').on('click', function(){
					$('.ms-control-shuffle').toggleClass('active');
				});

				// repeat
				$('#music_player .ms-control-repeat').on('click', function(){
					$(this).toggleClass('active');
				});

				// playlist
				$('#music_player .pl-list .tr-item .pl-audio-item').on('click', function(){
					var _index = $('#music_player .pl-list .tr-item').index( $(this).parents('.tr-item') );
					load_song(_index);
					play_song();
				});

			}
		});
	}



	$(window).load(function(){

		// page loaded
		$('body').addClass('page-loaded');

		// parallax columns
		$('.parallax-columns-container').parallaxColumn();

		//sticky
		$('.sticky-parent').each(function(){
			var _sticky = $(this),
				_this = this;
			_sticky.find('.sticky-column').theiaStickySidebar({
				containerSelector: _this,
	      		additionalMarginTop: 30,
	      		minWidth: 768
		    });
		});


		// masonry layout
		$('.masonry-layout').each(function(){
			var _masonry = $(this);
			var _col_width = _masonry.data('col-width') + '';
			if( _col_width.indexOf('col-')<0 ){
				_col_width = '.col-sm-2';
			}

			_masonry.isotope({
				itemSelector: '.masonry-item',
				masonry: {
                    columnWidth: _col_width
                }
			});

            _masonry.find('.fs-post-filter a').on('click', function(){
                var filter = $(this).data('filter');
                _masonry.isotope({ filter: filter });

                _masonry.find('.fs-post-filter li').removeClass('active');
                $(this).parent().addClass('active');
            });

		});


		$('.masonry-layout-alternate').each(function(){
			var _masonry = $(this);

			_masonry.isotope({
				itemSelector: '.masonry-item',
				masonry: {
                    columnWidth: 1
                }
			});
		});


        // Fullwidth section
        var fullscreen_func = function(){
            $('.fullwidth-section, .fullscreen-section').each(function(){
                var $this = $(this);
                var $wrapper = $('body');

                $this.css('margin-left', '0px');

                var margin_left = $this.offset().left-$wrapper.offset().left;
                var _width = $wrapper.width();

                $this.css({
                    'margin-left': -margin_left,
                    'width': _width+'px'
                });

                if( $this.hasClass('fullscreen-section') && !$this.hasClass('tt-slider') )
                    $this.height( $(window).height() );
            });
        };
        fullscreen_func();
        $(window).resize(function(){ fullscreen_func(); });



		// Parallax
	    $('[data-section-type="parallax"]').each(function(){
	        var _this = $(this);
	        var _bg = _this.css('background-image') + '';
	        _bg = _bg.replace('url("', '').replace('")', '');

	        _this.attr('data-stellar-ratio', '2');
	        _this.attr('data-stellar-background-ratio', '0.5');
	        _this.css('background-attachment', 'fixed');
	    });

	    if( !isTouchDevice() && $('[data-section-type="parallax"]').length ){
	        $(window).stellar({
	            horizontalScrolling: false,
	            verticalScrolling: true,
	            responsive: true,
	            verticalOffset: 0,
	            parallaxBackgrounds: true,
	            parallaxElements: false
	        });
	    }


	    /* Welcome page portfolio */
	    $('.welcome-folio').each(function(){
	    	var _folio = $(this);

	    	_folio.find('.wpf-viewport').isotope({
				itemSelector: '.masonry-item',
				masonry: {
                    columnWidth: '.col-lg-3'
                }
			});

            _folio.find('.wpf-filter a').on('click', function(){
                var filter = $(this).data('filter');
                _folio.find('.wpf-viewport').isotope({ filter: filter });

                _folio.find('.wpf-filter a.active').removeClass('active');
                $(this).addClass('active');
            });
	    });




	    // Big Title
	    var _slide_text_reset = function($title){
			$title.find('.entry-big-text').css({
				'-webkit-transition-duration': '0s',
				   '-moz-transition-duration': '0s',
					'-ms-transition-duration': '0s',
					 '-o-transition-duration': '0s',
						'transition-duration': '0s',
				'-webkit-transform': 'translateX(0px)',
				   '-moz-transform': 'translateX(0px)',
					'-ms-transform': 'translateX(0px)',
					 '-o-transform': 'translateX(0px)',
						'transform': 'translateX(0px)'
			});

			$title.load();
			_slide_text_left($title);
		};
		var _slide_text_left = function($title){
			var _transition = 0;
			if( $title.find('.entry-title-wrap').width() < $title.find('.entry-big-text').width() ){
				if( $title.find('.entry-big-text').find('span').length==0 ){
					var _title = $title.find('.entry-big-text').text();
					$title.find('.entry-big-text').html( '<span>'+_title+'</span>' + '<span>'+_title+'</span>' );
				}

				var _diff_width = $title.find('.entry-big-text').width() - 60;
				_diff_width = parseInt(_diff_width/2, 10);
				_diff_width += 60;
				_transition = _diff_width/80;
				$title.find('.entry-big-text').css({
    				'-webkit-transition-duration': _transition+'s',
    				   '-moz-transition-duration': _transition+'s',
    					'-ms-transition-duration': _transition+'s',
    					 '-o-transition-duration': _transition+'s',
    						'transition-duration': _transition+'s',
    				'-webkit-transform': 'translateX(-'+_diff_width+'px)',
    				   '-moz-transform': 'translateX(-'+_diff_width+'px)',
    					'-ms-transform': 'translateX(-'+_diff_width+'px)',
    					 '-o-transform': 'translateX(-'+_diff_width+'px)',
    						'transform': 'translateX(-'+_diff_width+'px)'
    			});

    			setTimeout(function(){
    				_slide_text_reset($title);
    			}, _transition*1000 );
			}
		};

	    $('.title-block[data-title]').each(function(){
	    	var $title = $(this),
	    		_title = $title.data('title');

    		$title.append( $('<span class="entry-title-wrap"></span>').append( $('<span class="entry-big-text"></span>').text(_title) ) );
    		_slide_text_left($title);
	    });




	    // audio, video playlist
	    $('.wp-playlist.wp-audio-playlist, .wp-playlist.wp-video-playlist, .wp-audio-shortcode, .wp-video-shortcode').each(function(){
	    	var $player = $(this);
	    	$player.find('.mejs-playpause-button button').html('<svg class="ms_icon_play" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 20 26" enable-background="new 0 0 20 26" xml:space="preserve"> \
													                <path d="M19.2,12.5L1.5,0.1C1.3,0,1,0,0.8,0.1C0.6,0.2,0.5,0.4,0.5,0.6v24.8c0,0.2,0.1,0.4,0.3,0.5C0.9,26,1,26,1.1,26c0.1,0,0.2,0,0.3-0.1l17.8-12.4c0.2-0.1,0.3-0.3,0.3-0.5C19.5,12.8,19.4,12.6,19.2,12.5z"/> \
													            </svg> \
													            <svg class="ms_icon_pause" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 20 26" enable-background="new 0 0 20 26" xml:space="preserve"> \
													                <path d="M8.3,25.1c0,0.5-0.4,0.9-0.9,0.9h-5c-0.5,0-0.9-0.4-0.9-0.9V0.9C1.5,0.4,1.9,0,2.4,0h5c0.5,0,0.9,0.4,0.9,0.9V25.1L8.3,25.1z"/> \
													                <path d="M18.5,25.1c0,0.5-0.4,0.9-0.9,0.9h-5c-0.5,0-0.9-0.4-0.9-0.9V0.9c0-0.5,0.4-0.9,0.9-0.9h5c0.5,0,0.9,0.4,0.9,0.9V25.1z"/> \
													            </svg>');

			$player.find('.mejs-volume-button button').html('<svg class="ec_volume_max" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 24 16" xml:space="preserve"> \
																<path d="M18.2,15.3c-0.2,0-0.4-0.1-0.6-0.3c-0.3-0.3-0.3-0.9,0-1.2C19.1,12.3,20,10.2,20,8c0-2.2-0.9-4.3-2.4-5.9c-0.3-0.3-0.3-0.9,0-1.2c0.3-0.3,0.9-0.3,1.2,0c1.9,1.9,2.9,4.4,2.9,7.1c0,2.7-1,5.2-2.9,7.1C18.6,15.2,18.4,15.3,18.2,15.3L18.2,15.3z M15.1,13.7c-0.2,0-0.4-0.1-0.6-0.3c-0.3-0.3-0.3-0.9,0-1.2c2.3-2.3,2.3-6.1,0-8.5c-0.3-0.3-0.3-0.9,0-1.2c0.3-0.3,0.9-0.3,1.2,0C17.2,4,18,5.9,18,8c0,2.1-0.8,4-2.3,5.5C15.6,13.6,15.4,13.7,15.1,13.7L15.1,13.7L15.1,13.7z M12.1,12.1c-0.2,0-0.4-0.1-0.6-0.3c-0.3-0.3-0.3-0.9,0-1.2c1.4-1.4,1.4-3.8,0-5.3c-0.3-0.3-0.3-0.9,0-1.2c0.3-0.3,0.9-0.3,1.2,0c2.1,2.1,2.1,5.6,0,7.7C12.5,12,12.3,12.1,12.1,12.1z"/> \
                                                                <path d="M9.7,16c-0.1,0-0.3-0.1-0.4-0.2l-4.4-4.4h-2c-0.3,0-0.6-0.3-0.6-0.6V5.1c0-0.3,0.3-0.6,0.6-0.6h2l4.4-4.4C9.5,0,9.7,0,9.9,0c0.2,0.1,0.4,0.3,0.4,0.5v14.9c0,0.2-0.1,0.4-0.4,0.5C9.9,16,9.8,16,9.7,16z"/> \
                                                            </svg> \
                                                            <svg class="ec_volume_mute" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 24 16" xml:space="preserve"> \
                                                                <path d="M15.4,16c-0.1,0-0.3-0.1-0.4-0.2l-4.4-4.4h-2c-0.3,0-0.6-0.3-0.6-0.6V5.1c0-0.3,0.3-0.6,0.6-0.6h2L15,0.2C15.2,0,15.4,0,15.6,0C15.9,0.1,16,0.3,16,0.6v14.9c0,0.2-0.1,0.4-0.4,0.5C15.6,16,15.5,16,15.4,16z"/> \
                                                            </svg>');
	    });

		$('.wp-playlist.wp-audio-playlist, .wp-playlist.wp-video-playlist').each(function(){
			var $list = $(this),
				_json_str = $list.find('script.wp-playlist-script').text(),
				_json = $.parseJSON(_json_str);

			$list.find('.wp-playlist-prev').html('<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 20 15" xml:space="preserve"> \
                                                        <path d="M0.1,7.2l9.5-6.7c0.1-0.1,0.2-0.1,0.4,0c0.1,0.1,0.2,0.2,0.2,0.3v6.3l9.3-6.6c0.1-0.1,0.2-0.1,0.4,0C19.9,0.5,20,0.6,20,0.8v13.5c0,0.1-0.1,0.3-0.2,0.3c-0.1,0-0.1,0-0.2,0c-0.1,0-0.1,0-0.2-0.1l-9.3-6.6v6.3c0,0.1-0.1,0.3-0.2,0.3c-0.1,0-0.1,0-0.2,0c-0.1,0-0.1,0-0.2-0.1L0.1,7.8C0.1,7.7,0,7.6,0,7.5C0,7.4,0.1,7.3,0.1,7.2z"/> \
                                                    </svg>');
			$list.find('.wp-playlist-next').html('<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 20 15" xml:space="preserve"> \
	                                                    <path d="M19.9,7.2l-9.5-6.7c-0.1-0.1-0.2-0.1-0.4,0C9.9,0.5,9.8,0.6,9.8,0.8v6.3L0.6,0.5c-0.1-0.1-0.2-0.1-0.4,0C0.1,0.5,0,0.6,0,0.8v13.5c0,0.1,0.1,0.3,0.2,0.3c0.1,0,0.1,0,0.2,0c0.1,0,0.1,0,0.2-0.1l9.3-6.6v6.3c0,0.1,0.1,0.3,0.2,0.3c0.1,0,0.1,0,0.2,0c0.1,0,0.1,0,0.2-0.1l9.5-6.7C19.9,7.7,20,7.6,20,7.5C20,7.4,19.9,7.3,19.9,7.2z"/> \
	                                                </svg>');

			var _table = $('<table class="wp-pl-head"></table>');
			_table.append('<tr> \
							<th class="wp-pl-th1">'+themeton_playlist_label.art+'</th> \
							<th class="wp-pl-th2">#</th> \
							<th class="wp-pl-th3">'+themeton_playlist_label.title+'</th> \
							<th class="wp-pl-th4">'+themeton_playlist_label.artist+'</th> \
							<th class="wp-pl-th5">'+themeton_playlist_label.time+'</th> \
						   </tr>');

		   $list.find('.wp-playlist-tracks').prepend(_table);

			$.each(_json.tracks, function(_index, _item){
				var _table = $('<table></table>'),
					_artist = '',
					_number = $('<span class="entry-pl-number"></span>');

				_number.append( $('<span class="pl-index"></span>').html(_index+1) );
				_number.append('<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 20 26" enable-background="new 0 0 20 26" xml:space="preserve"> \
					                <path d="M19.2,12.5L1.5,0.1C1.3,0,1,0,0.8,0.1C0.6,0.2,0.5,0.4,0.5,0.6v24.8c0,0.2,0.1,0.4,0.3,0.5C0.9,26,1,26,1.1,26c0.1,0,0.2,0,0.3-0.1l17.8-12.4c0.2-0.1,0.3-0.3,0.3-0.5C19.5,12.8,19.4,12.6,19.2,12.5z"/> \
					            </svg>');

				_table.append('<tr></tr>');
				_table.find('tr').append( $('<td class="wp-pl-td1"></td>').append( $('<img>').attr('src', _item.thumb.src) ) );
				_table.find('tr').append( $('<td class="wp-pl-td2"></td>').append(_number) );
				_table.find('tr').append( $('<td class="wp-pl-td3"></td>').html(_item.title) );

				if( typeof(_item.meta)!=='undefined' && typeof(_item.meta.artist)!=='undefined' ){
					_artist = _item.meta.artist;
				}
				_table.find('tr').append( $('<td class="wp-pl-td4"></td>').html(_artist) );

				_table.find('tr').append('<td class="wp-pl-td5">'+_item.meta.length_formatted+'</td>');
				$list.find('.wp-playlist-tracks').find('.wp-playlist-item').eq(_index).html('').append(_table);
			});
		});


	});


})(jQuery);
