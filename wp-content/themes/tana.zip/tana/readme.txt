Demo link: 
http://demo.themeton.com/tana

Download link:
https://themeforest.net/item/tana-magazine-news-portal-movie-blog-theme/16271685?ref=themeton